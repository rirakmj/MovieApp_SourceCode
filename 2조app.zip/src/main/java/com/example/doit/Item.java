package com.example.doit;

public class Item {
    boolean isSelected;

    public boolean getSelected()
    {
        return isSelected;
    }

    public void setSelected(boolean selected)
    {
        isSelected = selected;
    }
}

