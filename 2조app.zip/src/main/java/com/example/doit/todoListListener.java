package com.example.doit;

public interface todoListListener {
    void onItemClick(int position, String key);
}
