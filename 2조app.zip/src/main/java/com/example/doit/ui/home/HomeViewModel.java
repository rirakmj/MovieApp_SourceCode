package com.example.doit.ui.home;

import androidx.lifecycle.ViewModel;

public class HomeViewModel extends ViewModel {



    public HomeViewModel() {


    }


}