package com.example.onnuwhere.model.firstpage;

public class Document {
    private InitLoc documents;

    public InitLoc getDocuments() {
        return documents;
    }

    public void setDocuments(InitLoc documents) {
        this.documents = documents;
    }
}
