package com.example.onnuwhere.model;

import java.util.List;

public class ResultSearchKeyword {
    List<Place> documents;

    public List<Place> getDocuments() {
        return documents;
    }

    public void setDocuments(List<Place> documents) {
        this.documents = documents;
    }
}
