package com.example.onnuwhere;

public interface SearchListener {
    void SearchItemClick(int position);
}
